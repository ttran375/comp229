import BBG from '../src/assets/BBG.jpeg';
export default function Home() {
     return <>
     
     <p>Hello World!</p>
     <img src={BBG} alt="profile" className="bbg" />

     </>
     }
    