var lastName = "Smith";
var firstName = "John";
var middleName = "Doe";
 
console.log(`${lastName}, ${firstName} ${middleName}`);
 
