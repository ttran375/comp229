//As an example, let’s look at an arrow function with some default arguments:

const add = (x = 5, y = 10) => console.log(x + y);
