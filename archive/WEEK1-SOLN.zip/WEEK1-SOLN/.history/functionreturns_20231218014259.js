const logCompliment = function(firstName, message) {
console.log(`${firstName}: ${message}`);
};
logCompliment("Molly", "You're so cool");
