//var
var pizza = true;
pizza = false;
console.log(pizza); // false
