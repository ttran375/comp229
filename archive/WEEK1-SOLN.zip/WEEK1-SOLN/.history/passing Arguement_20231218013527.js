const logCompliment = function(firstName) {
    console.log(`You're doing great, ${firstName}`);
    };
    logCompliment("Molly");
    