const [firstAnimal]  = ["Horse",  "Mouse",  "Cat"];
console.log(firstAnimal);  // Horse