export default function Education() {
     return (
     <>
     <p>Education.Qualification</p>
     </>
     );
     }