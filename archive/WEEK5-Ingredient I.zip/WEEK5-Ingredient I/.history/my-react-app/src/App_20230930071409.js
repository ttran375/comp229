import React from 'react';
import ReactDOM from 'react-dom';

function IngredientsList() &nbsp;{&nbsp;
return React.createElement(
"ul",
{ &nbsp;className: "ingredients" },
React.createElement("li", &nbsp;null, &nbsp;"1 cup unsalted butter"),

React.createElement("li", null, "1 cup crunchy peanut butter"),
React.createElement("li", &nbsp;null, &nbsp;"1 cup brown sugar"),
React.createElement("li", &nbsp;null, &nbsp;"1 cup white sugar"),
React.createElement("li", &nbsp;null, &nbsp;"2 eggs"),
React.createElement("li", &nbsp;null, &nbsp;"2.5 cups all purpose flour"),
React.createElement("li", &nbsp;null, &nbsp;"1 teaspoon baking powder"),
React.createElement("li", &nbsp;null, &nbsp;"0.5 teaspoon salt")
);&nbsp;
}
ReactDOM.render(
React.createElement(IngredientsList, null, &nbsp;null),&nbsp;
document.getElementById("root")
);
ReactDOM.render(
  <Welcome />,  // Use <Welcome /> instead of <welcome>
  document.getElementById("root")
);

export default IngredientsList;