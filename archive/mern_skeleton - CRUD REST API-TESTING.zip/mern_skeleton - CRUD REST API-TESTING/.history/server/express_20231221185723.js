import express from 'express 
    const app = express()
   /*... configure express ... */ 
   export default app
