
    <section id="baked-salmon"> 
<h1>Baked Salmon</h1>
<ul class="ingredients"> 
<li>2 lb salmon</li>
<li>5 sprigs fresh rosemary</li> 
<li>2 tablespoons olive oil</li> 
<li>2 small lemons</li>
<li>1 teaspoon kosher salt</li> 
<li>4 cloves of chopped garlic</li>
</ul>
<section class="instructions"> 
<h2>Cooking Instructions</h2>
<p>Preheat the oven to 375 degrees.</p> 
<p>Lightly coat aluminum foil with oil.</p> 
<p>Place salmon on foil</p>
<p>Cover with rosemary, sliced lemons, chopped garlic.</p> 
<p>Bake for 15-20 minutes until cooked through.</p>
<p>Remove from oven.</p> 
</section>
</section>
</div>
